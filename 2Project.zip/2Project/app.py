from flask import Flask, render_template, request, redirect, url_for
from pymongo import MongoClient
from datetime import datetime, timezone

app = Flask(__name__)

# ─────────────────────────────────────────────────────────
#  Replace the URI below with your MongoDB Atlas connection
#  string.  You can also set the MONGO_URI env variable.
# ─────────────────────────────────────────────────────────
import os

MONGO_URI = os.getenv(
    "MONGO_URI",
    "mongodb+srv://deepshreegupta19_db_user:fEsqtTKJBO8Vx5M6@cluster1.mowo4vc.mongodb.net/?appName=Cluster1",
)

client     = MongoClient(MONGO_URI)
db         = client["formDB"]
collection = db["submissions"]


@app.route("/", methods=["GET", "POST"])
def form():
    if request.method == "POST":
        name    = request.form.get("name", "").strip()
        email   = request.form.get("email", "").strip()
        message = request.form.get("message", "").strip()

        if not name or not email or not message:
            return render_template(
                "form.html",
                error="All fields are required.",
                name=name, email=email, message=message,
            )

        try:
            collection.insert_one({
                "name":       name,
                "email":      email,
                "message":    message,
                "created_at": datetime.now(timezone.utc),
            })
            return redirect(url_for("success"))

        except Exception as exc:
            return render_template(
                "form.html",
                error=f"Database error: {exc}",
                name=name, email=email, message=message,
            )

    return render_template("form.html")


@app.route("/success")
def success():
    return render_template("success.html")


if __name__ == "__main__":
    app.run(debug=True, port=5000)
