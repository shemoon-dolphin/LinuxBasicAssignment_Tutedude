import json
from flask import Flask, jsonify

app = Flask(__name__)

DATA_FIlE ="data.json"


@app.route("/")
def home():
    return "Welcome! Visit <a href='/api'>/api</a> to see the JSON data."


@app.route("/api")
def get_data():
    with open (DATA_FIlE, "r") as f:
        data = json.load(f)
    return jsonify(data)    

if __name__ == "__main__":
    app.run(debug=True)