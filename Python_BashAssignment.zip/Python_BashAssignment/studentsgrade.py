students = {}
while True:
    print("\n--- Students grade menu ---")
    print("1. Add a new student and grade")
    print("2. Update an existing student’s grade")
    print("3. Print all student grades")
    print("4. exit")

    choice = input("enter your choice(1-4): ")     

    if choice == "1":
        name = input("Enter student name: ")
        if name in students:
            print(f"{name}already exist in with grade {students[name]}. use option 2 to update.")
        else:
            grade = input("Enter grade: ")
            students [name] = grade
            print(f"{name} added with grade {grade}.")

    elif choice == "2":
        name = input("enter a student name to update grade: ")     
        if name in students:
            print(f"Current grade for {name}: {students [name]}")  
            new_grade = input("enter new grade:")
            students[name] = new_grade
            print(f"grade updated to {new_grade}.")
        else:
            print(f"{name} doesn't exist. Use option 1 to add first.")

    elif choice == "3":
        if students:
            print("\n--- all students grades ---")
            for name, grade in students.items():
                print(f" {name}: {grade}")

    elif choice == "4":
        print("goodbye!")
        break


    else:
        print("invalid choice. Please enter 1, 2, 3, or 4")


                
        