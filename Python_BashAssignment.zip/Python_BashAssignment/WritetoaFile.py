file = open("samplefile.txt", "w")
file.write("Hello this is sample file.\n")
file.write("I am learning how to code on pyhton.\n")
file.write("I enrolled for 3 moth course completion from tutedude.\n")
file.write("This is for upskilling my skill.\n")
file.close()

print("file 'samplefile.tx' created.")

with open("samplefile.txt", "r") as file:
    print("\nfile contents:")
    print(file.read())